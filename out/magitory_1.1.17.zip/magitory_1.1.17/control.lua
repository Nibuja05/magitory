require "scripts/dungeon/control"
require "scripts/main/control"
require "scripts/util/control"
