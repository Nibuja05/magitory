script.on_event(defines.events.on_player_created, function(event)
    game.print("main/control.lua loaded")
end)